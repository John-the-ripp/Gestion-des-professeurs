#include <string>
using namespace std;

class etudiant{
    string nom;
    string prenom;
    unsigned int CNE;

   public:
   etudiant(string nom1="",string prenom1="",unsigned int CNE1=0);
   string getPrenom(){
       return prenom;
   }
   string getNom(){
       return nom;
   }
   unsigned int getCne(){
       return CNE;
   }
   void setPrenom(string prenom1){
       prenom = prenom1;
   }
    void setNom(string nom1){
       nom = nom1;
   }
    void setCne(unsigned int CNE1){
       CNE = CNE1;
   }
};
