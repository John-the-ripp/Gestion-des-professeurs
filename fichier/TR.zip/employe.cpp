#include "employe.h"
#include<string>
#include<iostream>
using namespace std;

employe::employe(unsigned int numEmploye1,unsigned int salaire1,string posteOccupe1){
    numEmploye=numEmploye1;
    salaire=salaire1;
    posteOccupe=posteOccupe1;
}
