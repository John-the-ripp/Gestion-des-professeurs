//#ifndef ETUDIANTEMPLOYE_H
//#define ETUDIANTEMPLOYE_H
#include "etudiant.h"
#include"employe.h"


class etudiantEmploye : public etudiant , public employe{
    public:
        etudiantEmploye(string nom1 , string prenom1 , unsigned int CNE1,unsigned int numEmploye1 , unsigned int salaire1 , string posteOccupe1);
        void affiche_etudiantEmploye();
};


