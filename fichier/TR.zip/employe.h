#include <string>
using namespace std;
class employe{
    unsigned int numEmploye;
    unsigned int salaire;
    string posteOccupe;
    public:
    employe(unsigned int numEmploye1=0,unsigned int salaire1=0,string posteOccupe1=0);
    string getPosteOccupe(){
       return posteOccupe;
   }
   unsigned int getSalaire(){
       return salaire;
   }
   unsigned int getNumEmploye(){
       return numEmploye;
   }
   void setPosteOccupe(string posteOccupe1){
       posteOccupe = posteOccupe1;
   }
    void setNumEmploye(unsigned int numEmploye1){
      numEmploye = numEmploye1;
   }
    void setSalaire(unsigned int salaire1){
       salaire = salaire1;
   }
};
