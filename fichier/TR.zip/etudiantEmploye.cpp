#include "etudiantEmploye.h"
#include "etudiant.h"
#include"employe.h"

using namespace std ;

etudiantEmploye::etudiantEmploye(string nom1 , string prenom1 , unsigned int CNE1,unsigned int numEmploye1 , unsigned int salaire1 , string posteOccupe1):etudiant(nom1,prenom1,CNE1),employe(numEmploye1,salaire1,posteEmploye1)

{

}
void etudiantEmploye::affiche_etudiantEmploye(){
    cout<<endl;
    this->affiche_etudiant();
    this->affiche_employe();
}
