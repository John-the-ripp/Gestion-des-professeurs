#include<iostream>
#include "etudiant.h"
#include<string>
using namespace std;

etudiant::etudiant(string nom1,string prenom1,unsigned int CNE1){
    nom=nom1;
    prenom=prenom1;
    CNE=CNE1;

}

