#include "employe.h"
#include "etudiant.h"
#include<string>
#include<iostream>
using namespace std;

int main(int argc, char *argv[]){
     etudiant E1("ziz","ilyas",178507);
     employe EP1(1,10000,"chef");

     std::cout<<"etudiant : ["<<E1.getNom()<<","<<E1.getPrenom()<<","<<E1.getCne()<<"] \n";
     std::cout<<"employe : ["<<EP1.getNumEmploye()<<","<<EP1.getSalaire()<<","<<EP1.getPosteOccupe()<<"]" ;


     EtudiantEmploye F1("ILYAS","ZIZ",1000,123,20000,"chef");
    F1.affiche_etudiantEmploye();

};
