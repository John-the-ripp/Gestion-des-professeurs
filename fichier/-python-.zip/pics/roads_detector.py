# -*- coding: utf-8 -*-
"""
Created on Fri Jan 14 07:50:21 2022

@author: lenovo
"""

import cv2
import pyttsx3
from tkinter import *
engine = pyttsx3.init('sapi5')
engine.setProperty('rate', 130)
engine.setProperty('Volume', 4.0)
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)

def speak(text):
    engine.say(text)
    engine.runAndWait()
def action_road():
    img = cv2.imread("C:/Users/lenovo/Desktop/pics/8.jpg")
    
    file = open("roads.txt", "r+")
    l=file.readlines()
    data=[]
    c=[]
    for i in range(len(l)):
        data.append(l[i].split(","))
    for i in range(len(data)):
        for j in range(len(data[0])):
            if j == len(data[0])-1 and "\n" in data[i][j]:
                data[i][j] = data[i][j].rstrip(data[i][j][-1])
                data[i][j]=int(data[i][j])
            else:
                data[i][j]=int(data[i][j])
    for i in range(len(data)):
        if "/"+str(data[i][0])+"." in "C:/Users/lenovo/Desktop/pics/8.jpg":
            image1 = cv2.rectangle(img, (data[i][1], data[i][2]), (data[i][3], data[i][4]), (150, 0, 0), 4)
            image1 = cv2.putText(img,'road' ,(data[i][1],data[i][2]),cv2.FONT_HERSHEY_PLAIN, 2 ,(0, 0, 255), 4)
            c.append([data[i][1], data[i][2],data[i][3],data[i][4]])
    if len(c)>0:
        image = cv2.resize(image1, (900, 550))
        cv2.imshow("image", image)
        print("the approximate height : ", (c[0][3]-c[0][1])/100, "m")
        speak("the approximate height of the road is: "+str((c[0][3]-c[0][1])/100)+ "meter")
        print("the approximate weight : ", (c[0][2]-c[0][0])/100, "m")
        speak("the approximate weight of the road is: "+str((c[0][2]-c[0][0])/100)+ "meter")
        cv2.waitKey(0)
    else:
        print("there is no road in the picture")
        speak("there is no road in the picture")


fenetre = Tk()
fenetre.geometry("400x400")
ok = Button(fenetre, text="road", command=action_road)
ok.pack()
fenetre.mainloop()