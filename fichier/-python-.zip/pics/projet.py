import cv2
from object_detector import *
import numpy as np
from tkinter import filedialog
from tkinter import *
from matplotlib import pyplot as pltd
import random

# Load Aruco detector



# Load Object Detector


# Load Image
#img = cv2.imread("1.jpg")
app = Tk()
app.filename =  filedialog.askopenfilename()
app.destroy()
img = cv2.imread(app.filename)
imgResize = cv2.resize(img, (1350,800))
#img_gray = cv2.cvtColor(imgResize, cv2.COLOR_BGR2GRAY)
imgCanny = cv2.Canny(imgResize, 400, 400)

# Get Aruco marker

detector = HomogeneousBgDetector()
contours = detector.detect_objects(imgResize)

# Draw objects boundaries
for cnt in contours:
    # Get rect
    rect = cv2.minAreaRect(cnt)
    (x, y), (w, h), angle = rect

    # Get Width and Height of the Objects by applying the Ratio pixel to cm


    # Display rectangle
    box = cv2.boxPoints(rect)
    box = np.int0(box)
    l = [0, 255]
    #cv2.circle(imgResize, (int(x), int(y)), 5, (0, 0, 255), -1)
    cv2.polylines(imgResize, [cnt], True, (random.choice(l),random.choice(l), random.choice(l)), 2)
    cv2.putText(imgResize, "Width {} cm".format(round(w, 1)), (int(x - 100), int(y - 20)), cv2.FONT_HERSHEY_PLAIN, 2, (100, 200, 0), 2)
    cv2.putText(imgResize, "Height {} cm".format(round(h, 1)), (int(x - 100), int(y + 15)), cv2.FONT_HERSHEY_PLAIN, 2, (100, 200, 0), 2)
#print((cnt))






cv2.imshow("Image", imgResize)
cv2.waitKey(0)